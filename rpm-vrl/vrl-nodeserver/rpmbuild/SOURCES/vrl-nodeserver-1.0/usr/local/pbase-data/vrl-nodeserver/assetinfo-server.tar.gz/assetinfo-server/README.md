### assetinfo-server

This Node JS service provides an API to read and update the ID3 tags on MP3 music files.

Build server in your local directory with
```
cd ~/work
git clone ...
cd assetinfo-server/
npm install

```

Launch server on port 3000 with:
```
cd ~/work/assetinfo-server/
node ./bin/www
```


##### GET assetdirectories - pass a directory path

`http://localhost:3000/assetdirectories?path=/var/www/html/mp3`

returns an array of file and directory names.
(The n field is only an ordering value only.)

```$json
[
    {
        "n": 0,
        "isMp3": false,
        "isDirectory": true,
        "path": "/var/www/html/mp3/Acoustic Crush",
        "name": "Acoustic Crush"
    },
    
  . . .
]
```

##### GET assetfiles with ID3 tags - pass a directory path
`http://localhost:3000/assetfiles?path=/var/www/html/mp3/Acoustic%20Crush`

returns an object with the filenames and info.  
(The id field is only an ordering value only.)
```$json
[
    {
        "id": 1004,
        "parentDir": "/var/www/html/mp3/Acoustic Crush/",
        "fileName": "Adam's Jam.mp3",
        "album": "In The City",
        "artist": "Acoustic Crush",
        "comment": "Copyright (c) 1997",
        "genre": "Rock",
        "title": "Adam's Jam",
        "track": 8,
        "isMp3": true,
        "isDirectory": false
    },
 
]
```

##### GET assetinfo - pass a filename

`http://127.0.0.1:3000/assetinfo?parentDir=/var/www/html/mp3/Brandy and Emo/&fileName=Jamie.mp3`

returns an object with the filename and MP3 tags  
```$json
{
    "parentDir": "/var/www/html/mp3/Brandy and Emo/",
    "fileName": "Jamie.mp3",
    "album": "Somewhere Near Salina",
    "artist": "Brandy and Emo",
    "comment": "Copyright (c) 2016",
    "genre": "Rock",
    "title": "Jamie",
    "track": 2
}
```



##### PUT assetinfo - update MP3 filename with tags in params payload

`http://127.0.0.1:3000/assetinfo`
with request payload:
```$json
{
    "parentDir": "/var/www/html/mp3/Acoustic Crush/",
    "fileName": "Adam's Jam.mp3",
    "album": "In The City",
    "artist": "Acoustic Crush",
    "comment": "Copyright (c) 1997",
    "genre": "Rock",
    "title": "Adam's Jam",
    "track": 8
}
```

returns the same params object


### systemd service

Service file named:
`/etc/systemd/system/nodeserver.service`

With contents like below, customized as needed:
```
[Unit]
Description=Node.js AssetInfo Server
#Requires=After=mysql.service       # example: if requires the mysql service to run first

[Service]
ExecStart=/usr/bin/node /opt/nodeserver/assetinfo-server/bin/www
# Required on some systems
WorkingDirectory=/opt/nodeserver/assetinfo-server
Restart=always
# Restart service after 10 seconds if node service crashes
RestartSec=10
# Output to syslog
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=assetinfo-server
#User=myalternateuser
#Group=myalternategroup
Environment=NODE_ENV=production PORT=3000

[Install]
WantedBy=multi-user.target
```

Enable and start the service:
```
systemctl enable nodeserver.service
systemctl start nodeserver.service
```

Check status:
```
systemctl status nodeserver.service
```
Check status and show log:
```
systemctl status -l nodeserver.service
```

Check the web page:
```
http://emosonic.com/assetinfo-api
```
