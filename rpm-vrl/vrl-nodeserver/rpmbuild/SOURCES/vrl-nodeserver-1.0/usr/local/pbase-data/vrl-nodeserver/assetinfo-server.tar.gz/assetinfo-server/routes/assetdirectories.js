var express = require('express');
var router = express.Router();
var fs = require('fs');

const { bindNodeCallback } = require('rxjs');

// GET
router.get('/', function(req, res, next) {
    var parentDirPath = req.query.path;
    if (!parentDirPath) {
        parentDirPath = '/var/www/mp3';
        // console.error('parentDirPath is undefined');
        // res.status(404).end();
    }

    console.log("");
    console.log("received GET assetdirectories parentDirPath: " + parentDirPath);

    const readdirObservable = bindNodeCallback(fs.readdir)(parentDirPath);

    readdirObservable.subscribe(
        (readdirRes) => {
            const filesArray = new Array(...readdirRes);
            // fetch filenames
            let resultFiles = [];
            filesArray.forEach(function(val, index) {
                resultFiles.push( {
                    index: index,
                    name: val,
                    isMp3: val.endsWith('.mp3') } );
            });

            // perform stat() on each file
            let dirStatBatch = [];

            resultFiles.forEach(function(val, index) {
                const filePath = parentDirPath + '/' + val.name;
                // console.log("filePath: " + filePath);
                const isDirectory = fs.statSync(filePath).isDirectory()
                dirStatBatch.push( { 'n': index, 'isMp3': val.isMp3, 'isDirectory': isDirectory, 'path': filePath, 'name': val.name } );
            });

            // send response
            res.json(dirStatBatch);

          },
        (error) => {
            console.error(error);
            const errMsg = { errno: error.errno, message: error.message};
            res.status(404).send(errMsg);

        }
        // ,
        // () => console.log('')
    );

});

module.exports = router;
