var express = require('express');
var router = express.Router();
var fs = require('fs');
var jsmediatags = require("jsmediatags");

const { bindNodeCallback, from, forkJoin } = require('rxjs');

// GET
router.get('/', function(req, res, next) {
    var parentDir = req.query.path;
    if (!parentDir) {
        console.error('parentDir is undefined');
        res.status(404).end();
    }

    if (! parentDir.endsWith('/')) {
        parentDir += '/';               // ensure trailing slash for directory path
    }
    console.log("");
    console.log("received GET assetfiles parentDir: " + parentDir);

    const readdirObservable = bindNodeCallback(fs.readdir)(parentDir);

    readdirObservable.subscribe(
        (readdirRes) => {
            const filesListText = readdirRes.toString();
            const filesArray = new Array(...readdirRes);
            // console.log(filesListText);

            // fetch filenames
            let resultFiles = [];
            filesArray.forEach(function(val, index) {
                resultFiles.push( {
                    index: index,
                    name: val,
                    isMp3: val.endsWith('.mp3') } );
            })

            let resultId3Tags = [];
            let n = 1001;

            // load id3 data
            let jsmediaObservableBatch = [];
            resultFiles.forEach(function(val, index) {
                if (val.isMp3) {
                    const filePath = parentDir + val.name;
                    // console.log("filePath: " + filePath);

                    const jsmediaReader = new jsmediatags.Reader(filePath).setTagsToRead(["album", "artist", "comment", "genre", "title", "track", "year"]);

                    const jsmediaReaderPromise = new Promise(resolve => {
                        new jsmediatags.Reader(filePath)
                            .setTagsToRead(["album", "artist", "comment", "genre", "title", "track", "year"])
                            .read({
                                onSuccess: tag => {
                                    tag.tags.fileName = val.name;
                                    resolve(tag);
                                },
                                onError: () => resolve(console.error(filePath))
                            });
                    });

                    const jsmediaObservable = from(jsmediaReaderPromise);
                    jsmediaObservableBatch.push(jsmediaObservable);
                }
                else {
                    const baseId3Tag = { 'n': n++, 'parentDir': parentDir, 'fileName': val.name, 'isDirectory': true , 'isMp3': false };
                    resultId3Tags.push(baseId3Tag);
                }
            });

            const observableBatch = forkJoin(jsmediaObservableBatch);

            observableBatch.subscribe(
                (tagBatch) => {
                    tagBatch.forEach(function (tag) {
                        const baseId3Tag = buildBaseId3Tag(parentDir, tag, n++);
                        resultId3Tags.push(baseId3Tag);
                        // console.log(' observableBatch.subscribe() baseId3Tag: ' + JSON.stringify(baseId3Tag));
                    });

                    // send response
                    res.json(resultId3Tags);
                }
            );

            if (jsmediaObservableBatch.length === 0) {
                res.json(resultId3Tags);
            }
          },
        (error) => console.error(error)
        // ,
        // () => console.log('')
    );

});

var buildBaseId3Tag = function(parentDir, tag, n) {
    if (!tag || !tag.tags) {
        return {};
    }
    const comment = tag.tags.comment ?  tag.tags.comment.text : '';

    const baseId3Tag = {
        id: n,
        parentDir: parentDir,
        fileName: tag.tags.fileName,
        album: tag.tags.album,
        artist: tag.tags.artist,
        comment: comment,
        genre: tag.tags.genre,
        title: tag.tags.title,
        track: tag.tags.track ? +tag.tags.track: undefined,
        year: tag.tags.year ? +tag.tags.year : undefined,
        isMp3: true,
        isDirectory: false
    };
    return baseId3Tag;
};

module.exports = router;
