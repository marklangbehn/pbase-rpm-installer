var express = require('express');
var router = express.Router();
var fs = require('fs');

var jsmediatags = require("jsmediatags");
var id3writer = require('id3-writer');

// GET
router.get('/', function(req, res, next) {
    var parentDir = req.query.parentDir;
    var fileName = req.query.fileName;
    if (!parentDir || !fileName) {
        console.error('both parentDir and fileName must be defined');
        res.status(404).end();
    }

    if (!parentDir.endsWith('/')) {
        parentDir += '/';
    }

    var filePath = parentDir + fileName;

    console.log("");
    console.log("received GET assetinfo path: " + filePath);

    new jsmediatags.Reader(filePath)
        .setTagsToRead(["album", "artist", "comment", "genre", "title", "track", "year"])
        .read({
            onSuccess: function(tag) {
                const baseId3Tag = buildBaseId3Tag(parentDir, fileName, tag);

                // let s = JSON.stringify(baseId3Tag);
                // console.log("        baseId3Tag: " + s);

                // send response
                res.json(baseId3Tag);
                // res.render('assetInfoGetResult', { title: 'assetinfo', filePath: filePath, baseId3Tag: s });
            },
            onError: function(err) {
                console.error(':(', err.type, err.info);
                res.status(404).end();
            }
        });

});

var buildBaseId3Tag = function(parentDir, fileName, tag) {
    const baseId3Tag = {
        parentDir: parentDir,
        fileName: fileName,
        album:  tag.tags.album,
        artist: tag.tags.artist,
        comment: tag.tags.comment ? tag.tags.comment.text : undefined,
        genre: tag.tags.genre,
        title: tag.tags.title,
        track: tag.tags.track ? +tag.tags.track : undefined,
        year: tag.tags.year ? +tag.tags.year : undefined
    };
    return baseId3Tag;
};

// PUT
router.put('/',function(req,res){
    console.log("");
    console.log("received PUT assetinfo fileName: " + req.body.fileName);

    const reqParams = {
        parentDir: req.body.parentDir,
        fileName:  req.body.fileName,
        artist:    req.body.artist,
        album:     req.body.album,
        comment:   req.body.comment,
        genre:     req.body.genre,
        title:     req.body.title,
        track:     req.body.track ? +req.body.track : undefined,
        year:      req.body.year ? +req.body.year : undefined
    };

    console.log("    reqParams: " + JSON.stringify(reqParams));

    var writer = new id3writer.Writer();

    var file = new id3writer.File(reqParams.parentDir + reqParams.fileName);
    let metaTags = {
        album:  reqParams.album,
        artist: reqParams.artist,
        comment: reqParams.comment,
        genre: reqParams.genre,
        title: reqParams.title,
        // track: +reqParams.track,    // ##REVISIT how to handle if track is undefined?
        // year:  reqParams.year       // ##REVISIT why does year fail when read back out after getting written to here? until then sidestep bug, just don't update year tag
    };

    if (reqParams.track) {
        metaTags.track = +reqParams.track;
    }

    // if (reqParams.year) {
    //     metaTags.year = +reqParams.year;
    // }
    var meta = new id3writer.Meta(metaTags, []);

    writer.setFile(file).write(meta, function(err) {
        if (err) {
            console.error(err);
            res.status(404).send('Not found');
        }
        console.log('    asset updated.');
        res.json(reqParams);
    });

});

module.exports = router;
